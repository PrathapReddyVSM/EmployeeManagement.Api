# Employee Management Frontend

React + TypeScript + Vite frontend for the Employee Management System.

## Features
- Login
- JWT token storage and Authorization header
- Employee create/update/delete
- Search employees
- Bulk delete
- Reports
- Department chart
- PDF export
- Responsive UI
- Basic validation and API error handling

## Run
1. Install Node.js.
2. Open this folder in VS Code.
3. Run `npm install`.
4. Copy `.env.example` to `.env`.
5. Set `VITE_API_BASE_URL` to your ASP.NET Web API URL.
6. Run `npm run dev`.

## Important API mapping
The sample frontend expects:
- POST `/api/Auth/login`
- GET `/api/Employee`
- GET `/api/Employee/{id}`
- POST `/api/Employee`
- PUT `/api/Employee/{id}`
- DELETE `/api/Employee/{id}`

If your backend controller or property names are different, update `src/api.ts` and the `Employee` interface in `src/types.ts`.

## Git
Do not commit `node_modules`. The provided `.gitignore` excludes it.

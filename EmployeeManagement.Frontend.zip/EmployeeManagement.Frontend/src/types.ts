export interface Employee {
  id: number;
  name: string;
  email: string;
  department: string;
  salary: number;
  phone?: string;
  joiningDate?: string;
}

export interface LoginResponse {
  token?: string;
  role?: string;
}
import axios from "axios";
import type { Employee } from "./types";

export const API_BASE_URL =
  import.meta.env.VITE_API_BASE_URL || "https://localhost:7000/api";

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: { "Content-Type": "application/json" }
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem("token");
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

export async function login(username: string, password: string) {
  const response = await api.post("/Auth/login", { username, password });
  return response.data;
}

export async function getEmployees(): Promise<Employee[]> {
  const response = await api.get("/Employee");
  return response.data;
}

export async function getEmployee(id: number): Promise<Employee> {
  const response = await api.get(`/Employee/${id}`);
  return response.data;
}

export async function createEmployee(employee: Omit<Employee, "id">) {
  const response = await api.post("/Employee", employee);
  return response.data;
}

export async function updateEmployee(id: number, employee: Omit<Employee, "id">) {
  const response = await api.put(`/Employee/${id}`, employee);
  return response.data;
}

export async function deleteEmployee(id: number) {
  await api.delete(`/Employee/${id}`);
}

export default api;